export interface card {
  name: string;
  id: number;
  data: Array<any>;
}

export interface cardData {
  description: string;
  likes: number;
}
